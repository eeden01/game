package dev.tilegame.state;

import java.awt.Graphics;

import dev.tilegame.Game;
import dev.tilegame.entities.creatures.Player;
import dev.tilegame.gfx.Assets;
import dev.tilegame.tiles.Tile;
import dev.tilegame.worlds.World;

public class GameState extends State {
	
	private Player player;
	private World world;

	
	
	public GameState(Game game) {
		super(game);
		player = new Player(game, 5, 5);
		world = new World(game, "res/worlds/world1.txt");
		
	}  
	
	@Override
	public void tick() {
		world.tick();
		player.tick();

		
	}

	@Override
	public void render(Graphics g) {
		world.render(g);
	
		Tile.tiles[1].render(g, 0, 0);
		player.render(g);
	}
	

}
