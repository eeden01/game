package dev.tilegame.state;

import java.awt.Graphics;

import dev.tilegame.Game;

public class MenuState extends State{

	public MenuState(Game game) {
		super(game);
		
	}
	
	@Override
	public void tick() {
		
	}

	@Override
	public void render(Graphics g) {
		
	}

}
