package dev.tilegame.state;

import java.awt.Graphics;

import dev.tilegame.Game;

public class SettingsState extends State{
	
	public SettingsState(Game game) {
		super(game);
		
	}

	@Override
	public void tick() {
		
	}

	@Override
	public void render(Graphics g) {
		
	}
	

}
