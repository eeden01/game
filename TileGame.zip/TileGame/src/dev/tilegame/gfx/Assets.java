package dev.tilegame.gfx;

import java.awt.image.BufferedImage;

public class Assets {
	
	private static final int width = 80, height = 80;
	
	
	public static BufferedImage player, dirt, grass, stone, tree;
	
	public static void init() {
		SpriteSheet sheet = new SpriteSheet(ImageLoader.loadImage("/textures/sheet.png"));
		SpriteSheet camperSheet = new SpriteSheet(ImageLoader.loadImage("/textures/campersheet.png"));
		
		player = camperSheet.crop(0, 0, 200, 200);
		dirt = sheet.crop(width, height, width, height);
		grass = sheet.crop(width * 2, height, width, height);
		stone = sheet.crop(width , 0, width, height);
		tree = sheet.crop(width * 5, height * 3, width, height);
	}

}
